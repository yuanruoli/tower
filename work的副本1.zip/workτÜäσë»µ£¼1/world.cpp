#include "world.h"
#include "icon.h"
#include "rpgobj.h"
#include <QMediaPlayer>
#include<iostream>
using namespace std;

World::~World(){
    delete this->_player;
}

void World::initWorld(string mapFile){
    //TODO ���������Ӧ�ø�Ϊ�ӵ�ͼ�ļ�װ��
    //player 5 5
    this->_player->initObj("player");
    this->_player->setPosX(100);
    this->_player->setPosY(100);

    /*RPGObj *p1 = new RPGObj;
    p1->initObj("stone");
    p1->setPosX(4);
    p1->setPosY(3);

    RPGObj *p2 = new RPGObj;
    p2->initObj("stone");
    p2->setPosX(6);
    p2->setPosY(5);*/

    /*RPGObj *p3 = new Fruit;
    p3->initObj("fruit");
    p3->setPosX(6);
    p3->setPosY(8);*/

    //forests background 1,2line
    RPGObj *p4= new RPGObj;
    p4->initObj("forests");
    p4->setPosX(0);
    p4->setPosY(2);
    this->_objs.push_back(p4);
    RPGObj *p5= new RPGObj;
    p5->initObj("forests");
    p5->setPosX(2);
    p5->setPosY(2);
    this->_objs.push_back(p5);
    RPGObj *p6= new RPGObj;
    p6->initObj("forests");
    p6->setPosX(4);
    p6->setPosY(2);
    this->_objs.push_back(p6);
    RPGObj *p7= new RPGObj;
    p7->initObj("forests");
    p7->setPosX(6);
    p7->setPosY(2);
    this->_objs.push_back(p7);
    RPGObj *p8= new RPGObj;
    p8->initObj("forests");
    p8->setPosX(8);
    p8->setPosY(2);
    this->_objs.push_back(p8);
    RPGObj *p9= new RPGObj;
    p9->initObj("forests");
    p9->setPosX(10);
    p9->setPosY(2);
    this->_objs.push_back(p9);
    RPGObj *p10= new RPGObj;
    p10->initObj("forests");
    p10->setPosX(12);
    p10->setPosY(2);
    this->_objs.push_back(p10);
    RPGObj *p11= new RPGObj;
    p11->initObj("forests");
    p11->setPosX(14);
    p11->setPosY(2);
    this->_objs.push_back(p11);
    RPGObj *p12= new RPGObj;
    p12->initObj("forests");
    p12->setPosX(14);
    p12->setPosY(2);
    this->_objs.push_back(p12);
    RPGObj *p13= new RPGObj;
    p13->initObj("forests");
    p13->setPosX(14);
    p13->setPosY(2);
    this->_objs.push_back(p13);
    RPGObj *p14= new RPGObj;
    p14->initObj("forests");
    p14->setPosX(16);
    p14->setPosY(2);
    this->_objs.push_back(p14);
    RPGObj *p15= new RPGObj;
    p15->initObj("forests");
    p15->setPosX(18);
    p15->setPosY(2);
    this->_objs.push_back(p15);
    RPGObj *p16= new RPGObj;
    p16->initObj("forests");
    p16->setPosX(20);
    p16->setPosY(2);
    this->_objs.push_back(p16);
    RPGObj *p17= new RPGObj;
    p17->initObj("forests");
    p17->setPosX(22);
    p17->setPosY(2);
    this->_objs.push_back(p17);

    //3 line
    RPGObj *p20= new RPGObj;
    p20->initObj("treegrass");
    p20->setPosX(0);
    p20->setPosY(4);
    this->_objs.push_back(p20);
    RPGObj *p18= new RPGObj;
    p18->initObj("tree");
    p18->setPosX(0);
    p18->setPosY(3);
    this->_objs.push_back(p18);

    RPGObj *p21= new RPGObj;
    p21->initObj("treegrass");
    p21->setPosX(3);
    p21->setPosY(4);
    this->_objs.push_back(p21);
    RPGObj *p19= new RPGObj;
    p19->initObj("tree");
    p19->setPosX(2);
    p19->setPosY(3);
    this->_objs.push_back(p19);
    RPGObj *p22= new RPGObj;
    p22->initObj("tree");
    p22->setPosX(4);
    p22->setPosY(3);
    this->_objs.push_back(p22);

    RPGObj *p23= new RPGObj;
    p23->initObj("road");
    p23->setPosX(0);
    p23->setPosY(5);
    this->_objs.push_back(p23);
    RPGObj *p24= new RPGObj;
    p24->initObj("road");
    p24->setPosX(3);
    p24->setPosY(5);
    this->_objs.push_back(p24);
    RPGObj *p25= new RPGObj;
    p25->initObj("road");
    p25->setPosX(0);
    p25->setPosY(6);
    this->_objs.push_back(p25);
    RPGObj *p26= new RPGObj;
    p26->initObj("road");
    p26->setPosX(3);
    p26->setPosY(6);
    this->_objs.push_back(p26);

    RPGObj *p27= new RPGObj;
    p27->initObj("sroad");
    p27->setPosX(8);
    p27->setPosY(5);
    this->_objs.push_back(p27);
    RPGObj *p28= new RPGObj;
    p28->initObj("sroad");
    p28->setPosX(7);
    p28->setPosY(5);
    this->_objs.push_back(p28);

    RPGObj *p29= new RPGObj;
    p29->initObj("treegrass");
    p29->setPosX(6);
    p29->setPosY(4);
    this->_objs.push_back(p29);
    RPGObj *p30= new RPGObj;
    p30->initObj("tree");
    p30->setPosX(6);
    p30->setPosY(3);
    this->_objs.push_back(p30);
    RPGObj *p34= new RPGObj;
    p34->initObj("tree");
    p34->setPosX(8);
    p34->setPosY(3);
    this->_objs.push_back(p34);

    RPGObj *p31= new RPGObj;
    p31->initObj("tree");
    p31->setPosX(8);
    p31->setPosY(3);
    this->_objs.push_back(p31);
    RPGObj *p32= new RPGObj;
    p32->initObj("forests");
    p32->setPosX(10);
    p32->setPosY(4);
    this->_objs.push_back(p32);
    RPGObj *p33= new RPGObj;
    p33->initObj("tree");
    p33->setPosX(9);
    p33->setPosY(4);
    this->_objs.push_back(p33);
    RPGObj *p35= new RPGObj;
    p35->initObj("ssroad");
    p35->setPosX(6);
    p35->setPosY(5);
    this->_objs.push_back(p35);
    RPGObj *p36= new RPGObj;
    p36->initObj("ssroad");
    p36->setPosX(6);
    p36->setPosY(6);
    this->_objs.push_back(p36);

    RPGObj *p37= new RPGObj;
    p37->initObj("forests");
    p37->setPosX(12);
    p37->setPosY(4);
    this->_objs.push_back(p37);
    RPGObj *p38= new RPGObj;
    p38->initObj("forests");
    p38->setPosX(14);
    p38->setPosY(4);
    this->_objs.push_back(p38);
    RPGObj *p39= new RPGObj;
    p39->initObj("forests");
    p39->setPosX(16);
    p39->setPosY(4);
    this->_objs.push_back(p39);
    RPGObj *p40= new RPGObj;
    p40->initObj("forests");
    p40->setPosX(18);
    p40->setPosY(4);
    this->_objs.push_back(p40);
    RPGObj *p41= new RPGObj;
    p41->initObj("forests");
    p41->setPosX(20);
    p41->setPosY(4);
    this->_objs.push_back(p41);
    RPGObj *p42= new RPGObj;
    p42->initObj("forests");
    p42->setPosX(22);
    p42->setPosY(4);
    this->_objs.push_back(p42);

    RPGObj *p43= new RPGObj;
    p43->initObj("treegrass");
    p43->setPosX(9);
    p43->setPosY(6);
    this->_objs.push_back(p43);
    RPGObj *p44= new RPGObj;
    p44->initObj("treegrass");
    p44->setPosX(12);
    p44->setPosY(6);
    this->_objs.push_back(p44);
    RPGObj *p45= new RPGObj;
    p45->initObj("treegrass");
    p45->setPosX(15);
    p45->setPosY(6);
    this->_objs.push_back(p45);
    RPGObj *p46= new RPGObj;
    p46->initObj("treegrass");
    p46->setPosX(18);
    p46->setPosY(6);
    this->_objs.push_back(p46);
    RPGObj *p47= new RPGObj;
    p47->initObj("treegrass");
    p47->setPosX(21);
    p47->setPosY(6);
    this->_objs.push_back(p47);

    RPGObj *p48= new RPGObj;
    p48->initObj("tree");
    p48->setPosX(10);
    p48->setPosY(5);
    this->_objs.push_back(p48);
    RPGObj *p49= new RPGObj;
    p49->initObj("tree");
    p49->setPosX(12);
    p49->setPosY(5);
    this->_objs.push_back(p49);
    RPGObj *p50= new RPGObj;
    p50->initObj("tree");
    p50->setPosX(14);
    p50->setPosY(5);
    this->_objs.push_back(p50);
    RPGObj *p51= new RPGObj;
    p51->initObj("tree");
    p51->setPosX(16);
    p51->setPosY(5);
    this->_objs.push_back(p51);
    RPGObj *p52= new RPGObj;
    p52->initObj("tree");
    p52->setPosX(18);
    p52->setPosY(5);
    this->_objs.push_back(p52);
    RPGObj *p53= new RPGObj;
    p53->initObj("tree");
    p53->setPosX(20);
    p53->setPosY(5);
    this->_objs.push_back(p53);
    RPGObj *p54= new RPGObj;
    p54->initObj("tree");
    p54->setPosX(22);
    p54->setPosY(5);
    this->_objs.push_back(p54);

    RPGObj *p55= new RPGObj;
    p55->initObj("treegrass");
    p55->setPosX(9);
    p55->setPosY(7);
    this->_objs.push_back(p55);
    RPGObj *p56= new RPGObj;
    p56->initObj("treegrass");
    p56->setPosX(12);
    p56->setPosY(7);
    this->_objs.push_back(p56);
    RPGObj *p57= new RPGObj;
    p57->initObj("treegrass");
    p57->setPosX(15);
    p57->setPosY(7);
    this->_objs.push_back(p57);
    RPGObj *p58= new RPGObj;
    p58->initObj("treegrass");
    p58->setPosX(18);
    p58->setPosY(7);
    this->_objs.push_back(p58);
    RPGObj *p60= new RPGObj;
    p60->initObj("treegrass");
    p60->setPosX(21);
    p60->setPosY(7);
    this->_objs.push_back(p60);

    RPGObj *p61= new RPGObj;
    p61->initObj("sroad");
    p61->setPosX(7);
    p61->setPosY(8);
    this->_objs.push_back(p61);
    RPGObj *p62= new RPGObj;
    p62->initObj("sroad");
    p62->setPosX(8);
    p62->setPosY(8);
    this->_objs.push_back(p62);

    RPGObj *p63= new RPGObj;
    p63->initObj("road");
    p63->setPosX(9);
    p63->setPosY(9);
    this->_objs.push_back(p63);
    RPGObj *p64= new RPGObj;
    p64->initObj("road");
    p64->setPosX(9);
    p64->setPosY(10);
    this->_objs.push_back(p64);

    RPGObj *p65= new RPGObj;
    p65->initObj("treegrass");
    p65->setPosX(9);
    p65->setPosY(8);
    this->_objs.push_back(p65);
    RPGObj *p66= new RPGObj;
    p66->initObj("treegrass");
    p66->setPosX(12);
    p66->setPosY(8);
    this->_objs.push_back(p66);
    RPGObj *p67= new RPGObj;
    p67->initObj("treegrass");
    p67->setPosX(15);
    p67->setPosY(8);
    this->_objs.push_back(p67);
    RPGObj *p68= new RPGObj;
    p68->initObj("treegrass");
    p68->setPosX(18);
    p68->setPosY(8);
    this->_objs.push_back(p68);
    RPGObj *p69= new RPGObj;
    p69->initObj("treegrass");
    p69->setPosX(21);
    p69->setPosY(8);
    this->_objs.push_back(p69);

    RPGObj *p70= new RPGObj;
    p70->initObj("rsign");
    p70->setPosX(9);
    p70->setPosY(6);
    this->_objs.push_back(p70);
    RPGObj *p71= new RPGObj;
    p71->initObj("tree");
    p71->setPosX(20);
    p71->setPosY(7);
    this->_objs.push_back(p71);
    RPGObj *p72= new RPGObj;
    p72->initObj("tree");
    p72->setPosX(11);
    p72->setPosY(7);
    this->_objs.push_back(p72);

    RPGObj *p73= new RPGObj;
    p73->initObj("board");
    p73->setPosX(0);
    p73->setPosY(7);
    this->_objs.push_back(p73);
    RPGObj *p74= new RPGObj;
    p74->initObj("1board");
    p74->setPosX(0);
    p74->setPosY(10);
    this->_objs.push_back(p74);

    RPGObj *p75= new RPGObj;
    p75->initObj("board");
    p75->setPosX(1);
    p75->setPosY(8);
    this->_objs.push_back(p75);
    RPGObj *p76= new RPGObj;
    p76->initObj("1board");
    p76->setPosX(1);
    p76->setPosY(7);
    this->_objs.push_back(p76);

    RPGObj *p77= new RPGObj;
    p77->initObj("board");
    p77->setPosX(2);
    p77->setPosY(7);
    this->_objs.push_back(p77);
    RPGObj *p78= new RPGObj;
    p78->initObj("1board");
    p78->setPosX(2);
    p78->setPosY(10);
    this->_objs.push_back(p78);

    RPGObj *p79= new RPGObj;
    p79->initObj("board");
    p79->setPosX(3);
    p79->setPosY(8);
    this->_objs.push_back(p79);
    RPGObj *p80= new RPGObj;
    p80->initObj("1board");
    p80->setPosX(3);
    p80->setPosY(7);
    this->_objs.push_back(p80);

    RPGObj *p81= new RPGObj;
    p81->initObj("board");
    p81->setPosX(4);
    p81->setPosY(7);
    this->_objs.push_back(p81);
    RPGObj *p82= new RPGObj;
    p82->initObj("1board");
    p82->setPosX(4);
    p82->setPosY(10);
    this->_objs.push_back(p82);

    RPGObj *p83= new RPGObj;
    p83->initObj("board");
    p83->setPosX(5);
    p83->setPosY(8);
    this->_objs.push_back(p83);
    RPGObj *p84= new RPGObj;
    p84->initObj("1board");
    p84->setPosX(5);
    p84->setPosY(7);
    this->_objs.push_back(p84);

    RPGObj *p85= new RPGObj;
    p85->initObj("board");
    p85->setPosX(6);
    p85->setPosY(7);
    this->_objs.push_back(p85);
    RPGObj *p86= new RPGObj;
    p86->initObj("1board");
    p86->setPosX(6);
    p86->setPosY(10);
    this->_objs.push_back(p86);

    RPGObj *p87= new RPGObj;
    p87->initObj("road");
    p87->setPosX(12);
    p87->setPosY(9);
    this->_objs.push_back(p87);
    RPGObj *p88= new RPGObj;
    p88->initObj("road");
    p88->setPosX(15);
    p88->setPosY(9);
    this->_objs.push_back(p88);
    RPGObj *p89= new RPGObj;
    p89->initObj("road");
    p89->setPosX(18);
    p89->setPosY(9);
    this->_objs.push_back(p89);
    RPGObj *p90= new RPGObj;
    p90->initObj("road");
    p90->setPosX(21);
    p90->setPosY(9);
    this->_objs.push_back(p90);

    RPGObj *p91= new RPGObj;
    p91->initObj("road");
    p91->setPosX(12);
    p91->setPosY(10);
    this->_objs.push_back(p91);
    RPGObj *p92= new RPGObj;
    p92->initObj("road");
    p92->setPosX(15);
    p92->setPosY(10);
    this->_objs.push_back(p92);
    RPGObj *p93= new RPGObj;
    p93->initObj("road");
    p93->setPosX(18);
    p93->setPosY(10);
    this->_objs.push_back(p93);
    RPGObj *p94= new RPGObj;
    p94->initObj("road");
    p94->setPosX(21);
    p94->setPosY(10);
    this->_objs.push_back(p94);

    RPGObj *p95= new RPGObj;
    p95->initObj("base");
    p95->setPosX(0);
    p95->setPosY(12);
    this->_objs.push_back(p95);
    RPGObj *p96= new RPGObj;
    p96->initObj("roof");
    p96->setPosX(0);
    p96->setPosY(10);
    this->_objs.push_back(p96);

    RPGObj *p97= new RPGObj;
    p97->initObj("board");
    p97->setPosX(4);
    p97->setPosY(11);
    this->_objs.push_back(p97);
    RPGObj *p98= new RPGObj;
    p98->initObj("1board");
    p98->setPosX(4);
    p98->setPosY(14);
    this->_objs.push_back(p98);

    RPGObj *p99= new RPGObj;
    p99->initObj("board");
    p99->setPosX(5);
    p99->setPosY(12);
    this->_objs.push_back(p99);
    RPGObj *p100= new RPGObj;
    p100->initObj("1board");
    p100->setPosX(5);
    p100->setPosY(11);
    this->_objs.push_back(p100);

    RPGObj *px1= new RPGObj;
    px1->initObj("board");
    px1->setPosX(6);
    px1->setPosY(11);
    this->_objs.push_back(px1);
    RPGObj *px2= new RPGObj;
    px2->initObj("1board");
    px2->setPosX(6);
    px2->setPosY(14);
    this->_objs.push_back(px2);

    RPGObj *px3= new RPGObj;
    px3->initObj("board");
    px3->setPosX(8);
    px3->setPosY(11);
    this->_objs.push_back(px3);
    RPGObj *px4= new RPGObj;
    px4->initObj("1board");
    px4->setPosX(8);
    px4->setPosY(14);
    this->_objs.push_back(px4);

    RPGObj *px5= new RPGObj;
    px5->initObj("board");
    px5->setPosX(7);
    px5->setPosY(12);
    this->_objs.push_back(px5);
    RPGObj *px6= new RPGObj;
    px6->initObj("1board");
    px6->setPosX(7);
    px6->setPosY(11);
    this->_objs.push_back(px6);

    RPGObj *px7= new RPGObj;
    px7->initObj("board");
    px7->setPosX(10);
    px7->setPosY(11);
    this->_objs.push_back(px7);
    RPGObj *px8= new RPGObj;
    px8->initObj("1board");
    px8->setPosX(10);
    px8->setPosY(14);
    this->_objs.push_back(px8);

    RPGObj *px9= new RPGObj;
    px9->initObj("board");
    px9->setPosX(9);
    px9->setPosY(12);
    this->_objs.push_back(px9);
    RPGObj *px10= new RPGObj;
    px10->initObj("1board");
    px10->setPosX(9);
    px10->setPosY(11);
    this->_objs.push_back(px10);

    RPGObj *px11= new RPGObj;
    px11->initObj("board");
    px11->setPosX(11);
    px11->setPosY(12);
    this->_objs.push_back(px11);
    RPGObj *px12= new RPGObj;
    px12->initObj("1board");
    px12->setPosX(11);
    px12->setPosY(11);
    this->_objs.push_back(px12);

    RPGObj *px13= new RPGObj;
    px13->initObj("board");
    px13->setPosX(12);
    px13->setPosY(11);
    this->_objs.push_back(px13);
    RPGObj *px14= new RPGObj;
    px14->initObj("1board");
    px14->setPosX(12);
    px14->setPosY(14);
    this->_objs.push_back(px14);

    RPGObj *px15= new RPGObj;
    px15->initObj("board");
    px15->setPosX(13);
    px15->setPosY(12);
    this->_objs.push_back(px15);
    RPGObj *px16= new RPGObj;
    px16->initObj("1board");
    px16->setPosX(13);
    px16->setPosY(11);
    this->_objs.push_back(px16);

    RPGObj *px17= new RPGObj;
    px17->initObj("board");
    px17->setPosX(14);
    px17->setPosY(11);
    this->_objs.push_back(px17);
    RPGObj *px18= new RPGObj;
    px18->initObj("1board");
    px18->setPosX(14);
    px18->setPosY(14);
    this->_objs.push_back(px18);

    RPGObj *px19= new RPGObj;
    px19->initObj("board");
    px19->setPosX(15);
    px19->setPosY(12);
    this->_objs.push_back(px19);
    RPGObj *px20= new RPGObj;
    px20->initObj("1board");
    px20->setPosX(15);
    px20->setPosY(11);
    this->_objs.push_back(px20);

    RPGObj *px21= new RPGObj;
    px21->initObj("board");
    px21->setPosX(16);
    px21->setPosY(11);
    this->_objs.push_back(px21);
    RPGObj *px22= new RPGObj;
    px22->initObj("1board");
    px22->setPosX(16);
    px22->setPosY(14);
    this->_objs.push_back(px22);

    RPGObj *px23= new RPGObj;
    px23->initObj("board");
    px23->setPosX(17);
    px23->setPosY(12);
    this->_objs.push_back(px23);
    RPGObj *px24= new RPGObj;
    px24->initObj("1board");
    px24->setPosX(17);
    px24->setPosY(11);
    this->_objs.push_back(px24);

    RPGObj *px25= new RPGObj;
    px25->initObj("board");
    px25->setPosX(18);
    px25->setPosY(11);
    this->_objs.push_back(px25);
    RPGObj *px26= new RPGObj;
    px26->initObj("1board");
    px26->setPosX(18);
    px26->setPosY(14);
    this->_objs.push_back(px26);

    RPGObj *px27= new RPGObj;
    px27->initObj("board");
    px27->setPosX(19);
    px27->setPosY(12);
    this->_objs.push_back(px27);
    RPGObj *px28= new RPGObj;
    px28->initObj("1board");
    px28->setPosX(19);
    px28->setPosY(11);
    this->_objs.push_back(px28);

    RPGObj *px29= new RPGObj;
    px29->initObj("board");
    px29->setPosX(20);
    px29->setPosY(11);
    this->_objs.push_back(px29);
    RPGObj *px30= new RPGObj;
    px30->initObj("1board");
    px30->setPosX(20);
    px30->setPosY(14);
    this->_objs.push_back(px30);

    RPGObj *px31= new RPGObj;
    px31->initObj("board");
    px31->setPosX(21);
    px31->setPosY(12);
    this->_objs.push_back(px31);
    RPGObj *px32= new RPGObj;
    px32->initObj("1board");
    px32->setPosX(21);
    px32->setPosY(11);
    this->_objs.push_back(px32);

    RPGObj *px33= new RPGObj;
    px33->initObj("board");
    px33->setPosX(22);
    px33->setPosY(11);
    this->_objs.push_back(px33);
    RPGObj *px34= new RPGObj;
    px34->initObj("1board");
    px34->setPosX(22);
    px34->setPosY(14);
    this->_objs.push_back(px34);

    RPGObj *px35= new RPGObj;
    px35->initObj("board");
    px35->setPosX(23);
    px35->setPosY(12);
    this->_objs.push_back(px35);
    RPGObj *px36= new RPGObj;
    px36->initObj("1board");
    px36->setPosX(23);
    px36->setPosY(11);
    this->_objs.push_back(px36);

    //decorations
    //haystack

    RPGObj *px37= new RPGObj;
    px37->initObj("haystack");
    px37->setPosX(22);
    px37->setPosY(13);
    this->_objs.push_back(px37);
    RPGObj *px38= new RPGObj;
    px38->initObj("fork");
    px38->setPosX(22);
    px38->setPosY(13);
    this->_objs.push_back(px38);

    RPGObj *px39= new RPGObj;
    px39->initObj("winebott");
    px39->setPosX(4);
    px39->setPosY(12);
    this->_objs.push_back(px39);

    RPGObj *px40= new RPGObj;
    px40->initObj("tree");
    px40->setPosX(18);
    px40->setPosY(7);
    this->_objs.push_back(px40);
    RPGObj *px41= new RPGObj;
    px41->initObj("tree");
    px41->setPosX(16);
    px41->setPosY(7);
    this->_objs.push_back(px41);
    RPGObj *px42= new RPGObj;
    px42->initObj("tree");
    px42->setPosX(14);
    px42->setPosY(7);
    this->_objs.push_back(px42);

    RPGObj *px43= new RPGObj;
    px43->initObj("well");
    px43->setPosX(18);
    px43->setPosY(11);
    this->_objs.push_back(px43);

    RPGObj *px44= new RPGObj;
    px44->initObj("wines");
    px44->setPosX(20);
    px44->setPosY(11);
    this->_objs.push_back(px44);
    RPGObj *px45= new RPGObj;
    px45->initObj("wines");
    px45->setPosX(20);
    px45->setPosY(12);
    this->_objs.push_back(px45);
    //this->_objs.push_back(p1);
    //this->_objs.push_back(p2);
    //this->_objs.push_back(p3);


    QMediaPlayer * player = new QMediaPlayer;
    player->setMedia(QUrl("qrc:/sounds/hdl.mp3"));
    player->setVolume(30);
    player->play();


}


void World::show(QPainter * painter){
    int n = this->_objs.size();
    for (int i=0;i<n;i++){
        this->_objs[i]->show(painter);
    }
    this->_player->show(painter);



}

void World::eraseObj(int x, int y){
    vector<RPGObj*>::iterator it;
    it = _objs.begin();
    while(it!=_objs.end()){
        int flag1 = ((*it)->getObjType()!="stone"); //����ʯͷ
        int flag2 = ((*it)->getPosX() == x) && ((*it)->getPosY()==y);//λ���ص�

        if (flag1 && flag2){
            cout<<(*it)->getObjType()<<endl;
            (*it)->onErase();
            delete (*it);
            it = this->_objs.erase(it);
            break;
         }
        else{
            it++;
        }
    }

}

void World::handlePlayerMove(int direction, int steps){
    int x =  this->_player->getNextX(direction);
    int y = this->_player->getNextY(direction);
    this->eraseObj(x,y);
    this->_player->move(direction, steps);
}

