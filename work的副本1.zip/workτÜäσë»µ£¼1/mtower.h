#ifndef MTOWER_H
#define MTOWER_H
#include "rpgobj.h"
#include <QMediaPlayer>
using namespace std;

class mtower:public RPGObj
{
public:
    mtower(){}
    ~mtower(){}
    void move(int direction, int steps=1);
protected:
    int _health;
    int _attack;
    int _istower;
};


#endif // MTOWER_H
