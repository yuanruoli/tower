#ifndef GAME_H
#define GAME_H

#include <QGraphicsView>
#include <QWidget>
#include <QMouseEvent>
#include "tower.h"
#include "tower2.h"
#include "health.h"
#include "gold.h"
#include <QTimer>
#include "round.h"
#include <firsttowericon.h>
#include "secondtowericon.h"
#include <QGraphicsPixmapItem>

class Game: public QGraphicsView {
    Q_OBJECT
public:
    //member functions
    Game();
    void setCursor(QString filename);
    void mouseMoveEvent(QMouseEvent *event);
    void mousePressEvent(QMouseEvent *event);
    void createEnemies(int numberofEnemies);
    void createEnemies2(int numberofEnemies);
    void createEnemies21(int numberofEnemies);
    void createEnemies22(int numberofEnemies);
    void createRoad();
    bool gameover();


    //member attributes
    QGraphicsScene *scene;
    QGraphicsPixmapItem *cursor;
    Tower* build;
    Tower2* build2;
    QTimer* spawnTimer;
    QTimer* spawnTimer2;
    QTimer* spawnTimer21;
    QTimer* spawnTimer22;
    Health *health;
    BuildFirstTowerIcon *ft;
    BuildSecondTowerIcon *ft2;

    gold *gold1;
    Round *round0;
    int enemySpawned;
    int maxNumberOfEnemies;
    int enemySpawned2;
    int maxNumberOfEnemies2;
    int enemySpawned21;
    int maxNumberOfEnemies21;
    int enemySpawned22;
    int maxNumberOfEnemies22;
    QList<QPointF> pointsToFollow;
    QList<QPointF> pointsToFollow2;
public slots:
    void spawnEnemy();
    void spawnEnemy2();
    void spawnEnemy21();
    void spawnEnemy22();
private:
    int timerId;
};

#endif // GAME_H
