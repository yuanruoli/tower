#include "secondtowericon.h"
#include "game.h"
#include "secondtower.h"
#include <QDebug>

extern Game *game;

BuildSecondTowerIcon::BuildSecondTowerIcon(QGraphicsItem *parent): QGraphicsPixmapItem(parent)
{
    setPixmap(QPixmap(":/resourses/pic/arrowtower.png"));

}

void BuildSecondTowerIcon::mousePressEvent(QGraphicsSceneMouseEvent *event){
    if(!game->build2){
        if(game->gold1->getGold()>=1500)//new comer
        {
            game->build2 =  new SecondTower();
            game->setCursor(QString(":/resourses/pic/arrowtower.png"));
            for(int i=0;i<1500;i++)
                game->gold1->decrease();
        }
    }
    count++;
}
