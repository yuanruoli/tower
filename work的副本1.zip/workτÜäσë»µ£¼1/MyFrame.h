#ifndef MYFRAME_H
#define MYFRAME_H

#include <QWidget>
#include <QtGui>

class MyFrame : public QWidget
{
public:
    MyFrame();
    void paintEvent(QPaintEvent *event);
};

#endif // MYFRAME_H
