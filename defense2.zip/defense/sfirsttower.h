#ifndef SFIRSTTOWER_H
#define SFIRSTTOWER_H
#include "stower.h"
#include <QGraphicsPixmapItem>
#include <QGraphicsSceneMouseEvent>

class SFirstTower:public STower{
    Q_OBJECT
public:
    SFirstTower(QGraphicsItem *parent=0);
    void fire();
public slots:
    void acquire_target();
};




#endif // SFIRSTTOWER_H
