#include <Health.h>
#include <QFont>
#include <QDebug>


Health::Health(QGraphicsItem *parent):QGraphicsTextItem(parent)
{
    //initialize Health to 10
    health = 50;
    //text
    setPlainText(QString("Health: ")+ QString::number(health));
    setDefaultTextColor(Qt::blue);
    setFont(QFont("times",20));//16
}

void Health::decrease()
{
    health --;
    setPlainText(QString("Health: ")+ QString::number(health));
    //qDebug()<<health;

}

void Health::increase()
{
    health ++;
    setPlainText(QString("Health: ")+ QString::number(health));
    //qDebug()<<health;

}

int Health::getHealth()const
{
    return health;
}
