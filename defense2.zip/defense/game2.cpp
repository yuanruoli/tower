#include "game2.h"
#include <QGraphicsScene>
#include "stower.h"
#include "sbullet.h"
#include "enemy.h"
#include "enemy3.h"
#include "sfirsttowericon.h"
#include "sfirsttower.h"
#include "QGraphicsLineItem"
#include "round.h"
#include <QDebug>
#include <QBrush>
#include <QImage>
#include <QGraphicsView>

Game2::Game2(): QGraphicsView()
{
    // create a scene
    scene2 = new QGraphicsScene();
    scene2->setSceneRect(0,0,1200,1000);

    //set background
    scene2->setBackgroundBrush(QBrush(QImage(":/resourses/pic/map2.png")));

    //set scene
    setScene(scene2);

    //set cursor
    cursor2 = nullptr;
    build2= nullptr;
    QGraphicsView::setMouseTracking(true);

    //change window
    setFixedSize(1200,1000);
    setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);

    //create a enemy
    spawnTimer = new QTimer(this);
    enemySpawned = 0;
    maxNumberOfEnemies = 0;
    spawnTimer2 = new QTimer(this);
    enemySpawned2 = 0;
    maxNumberOfEnemies2 = 0;
    pointsToFollow <<  QPointF(1200,200)<<QPointF(1000,300)<<QPoint(20,370)<<QPointF(20,370)
                    <<QPointF(20,370)<< QPointF(20,370)<<QPointF(20,370)
                     ;
    createEnemies(5);
    createEnemies(5);


    for(int i=0;i<31;i++)
    {
        createEnemies2(5);
    }

    //create road
    createRoad();

    //test code
    ft = new SBuildFirstTowerIcon();

    scene2->addItem(ft);


    //health
    health = new Health();
    health->setPos(x()+100,y()+40);
    scene2->addItem(health);

    //gold
    gold1 = new gold();
    gold1->setPos(x()+100,y()+70);
    scene2->addItem(gold1);

}

void Game2::setCursor(QString filename)
{
    if(cursor2){
        scene2->removeItem(cursor2);
        delete cursor2;
    }
    cursor2 = new QGraphicsPixmapItem();
    cursor2->setPixmap(QPixmap(filename));
    scene2->addItem(cursor2);
}

void Game2::mouseMoveEvent(QMouseEvent *event)
{
    if(cursor2){
        cursor2->setPos(event->pos());
    }
}

void Game2::mousePressEvent(QMouseEvent *event)
{
    if(build2){
        scene2->addItem(build2);
        build2->setPos(event->pos());
        cursor2 = nullptr;
        build2 = nullptr;
        //only allow 1 towers
        if(ft->count==6)
        {
            scene2->removeItem(ft);
        }

    }
    else{
        QGraphicsView::mousePressEvent(event);
    }
}


void Game2::createEnemies(int numberofEnemies)
{
    enemySpawned = 0;
    maxNumberOfEnemies = numberofEnemies;
    connect(spawnTimer,SIGNAL(timeout()),this,SLOT(spawnEnemy()));
    spawnTimer->start(1500);

}

void Game2::createEnemies2(int numberofEnemies)
{
    enemySpawned2 = 0;
    maxNumberOfEnemies2 = numberofEnemies;
    connect(spawnTimer2,SIGNAL(timeout()),this,SLOT(spawnEnemy2()));
    spawnTimer2->start(40000);

}

void Game2::createRoad()
{
    for (size_t i = 0, n = pointsToFollow.size()-1; i < n; i++)
    {
        //create line
        QLineF line(pointsToFollow[i],pointsToFollow[i+1]);
        QGraphicsLineItem *lineItem = new QGraphicsLineItem(line);
        //widht and color
        /*QPen pen;
        pen.setWidth(5);
        pen.setColor(Qt::darkCyan);
        //set pend and add to scene
        lineItem->setPen(pen);
        scene2->addItem(lineItem);*/
    }
}

void Game2::spawnEnemy()
{
    //spwan an enemy
    Enemy *enemy = new Enemy(pointsToFollow);
    enemy->setPos(pointsToFollow[0]);
    scene2->addItem(enemy);
    int i=0;
    //scene->addItem(enemy1);
    enemySpawned+=1;

//maxNumberOfEnemies take charge of the hard level
    if(enemySpawned >= maxNumberOfEnemies){
        spawnTimer->start(1500);//1500
    }
}

void Game2::spawnEnemy2()
{
    //spwan an enemy
    Enemy3 *enemy = new Enemy3(pointsToFollow);
    enemy->setPos(pointsToFollow[0]);
    scene2->addItem(enemy);
    int i=0;
    //scene->addItem(enemy1);
    enemySpawned2+=1;

//maxNumberOfEnemies take charge of the hard level
    if(enemySpawned2 >= maxNumberOfEnemies2){
        spawnTimer2->start(50000);
    }
}

