#ifndef SFIRSTTOWERICON_H
#define SFIRSTTOWERICON_H


#include <QGraphicsPixmapItem>
#include <QGraphicsSceneMouseEvent>
class SBuildFirstTowerIcon: public QGraphicsPixmapItem{
public:
    SBuildFirstTowerIcon(QGraphicsItem *parent=0);
    void mousePressEvent(QGraphicsSceneMouseEvent *event);
    //propety
    int count;
};

#endif // SFIRSTTOWERICON_H
