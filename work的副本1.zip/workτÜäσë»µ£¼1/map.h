#ifndef MAP_H
#define MAP_H


class map
{
public:
    map();
};

#endif // MAP_H