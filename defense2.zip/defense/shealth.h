#ifndef SHEALTH_H
#define SHEALTH_H


#include <QGraphicsTextItem>

class SHealth: public QGraphicsTextItem{
public:
    SHealth(QGraphicsItem *parent = 0);
    void decrease();
    int getHealth();
    void increase();
private:
    int health;
};



#endif // SHEALTH_H
