#include "gold.h"
#include <QFont>
#include <QImage>
#include <QPainter>
#include <QPaintEvent>
#include <QPushButton>
gold::gold(QGraphicsItem *parent):QGraphicsTextItem(parent)
  //initialize Gold to 500
{
    _gold=500;
    //text out
    /*QPixmap arrayImage(":/resourses/pic/arrowtower.png"); //图片路径
    QRect arrayRect(100,100,200,200); //截取图片区域
    QPainter painter;
    painter.drawPixmap(QPoint(100,100),arrayImage,arrayRect); //打印图片*/


    setPlainText(QString("Gold: ")+ QString::number(_gold));
    setDefaultTextColor(Qt::darkGreen);
    setFont(QFont("times",20));
}
//painter.drawLine(0,0,100,100);
void gold::decrease()
{
    _gold--;
    setPlainText(QString("Gold ")+ QString::number(_gold));
}
void gold::increase()
{
    _gold++;
    setPlainText(QString("Gold ")+ QString::number(_gold));
}
int gold::getGold()
{
    return _gold;
}

/*void Health::decrease()
{
    health--;
    setPlainText(QString("Health: ")+ QString::number(health));
}

int Health::getHealth()
{
    return health;
}
*/
