#include "mainwindow.h"
#include <QPushButton>
#include <QMessageBox>
#include "round.h"

Game *game;
Game2 *game2;
MainWindow::MainWindow()
{
    //choose round
    QWidget *choose = new QWidget();
    choose->show();
    QPushButton *but1 = new QPushButton(choose);
    but1->move(100, 150);
    but1->setFixedSize(120, 40);
    but1->setText("CHAPTER 1");
    but1->show();
    QPushButton *but2 = new QPushButton(choose);
    but2->move(350, 150);
    but2->setFixedSize(120, 40);
    but2->show();
    but2->setText("CHARPTER 2");

    QObject::connect(but1, &QPushButton::clicked, this, &MainWindow::start1);
    QObject::connect(but2, &QPushButton::clicked, this, &MainWindow::start2);

}

void MainWindow::start1() {

    game = new Game();
    game->show();

}

void MainWindow::start2() {
     game2 = new Game2();
     game2->show();
}

void MainWindow::gameover() {
    if(game->gameover()){
            game->close();
            QMessageBox msgBox;
            msgBox.setText("WIN!!");
            msgBox.exec();
            msgBox.setFixedSize(500,500);

     }
}

