#include "enemy.h"

/*enemy::enemy()
{

}*/
