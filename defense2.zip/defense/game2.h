#ifndef GAME2_H
#define GAME2_H

#include <QGraphicsView>
#include <QWidget>
#include <QMouseEvent>
#include "stower.h"
#include "health.h"
#include "round.h"
#include "gold.h"
#include <QTimer>
#include <sfirsttowericon.h>

class Game2: public QGraphicsView {
    Q_OBJECT
public:
    //member functions
    Game2();
    void setCursor(QString filename);
    void mouseMoveEvent(QMouseEvent *event);
    void mousePressEvent(QMouseEvent *event);
    void createEnemies(int numberofEnemies);
    void createEnemies2(int numberofEnemies);
    void createRoad();


    //member attributes
    QGraphicsScene *scene2;
    QGraphicsPixmapItem *cursor2;
    STower* build2;
    QTimer* spawnTimer;
    QTimer* spawnTimer2;
    Health *health;
    SBuildFirstTowerIcon *ft;
    gold *gold1;
    int enemySpawned;
    int maxNumberOfEnemies;
    int enemySpawned2;
    int maxNumberOfEnemies2;
    Round *round0;
    QList<QPointF> pointsToFollow;
    QList<QPointF> pointsToFollow2;
public slots:
    void spawnEnemy();
    void spawnEnemy2();
};

#endif // GAME2_H
