#ifndef SENEMY_H
#define SENEMY_H
#include <QGraphicsPixmapItem>
#include <QObject>
#include <QList>
#include <QPointF>

class SEnemy: public QObject, public QGraphicsPixmapItem{
    Q_OBJECT
public:
    SEnemy(QList<QPointF> pointsToFollow,QGraphicsItem *parent = 0);
    void rotateToPoint(QPointF p);
    int health=100;
    //void fire();
public slots:
    void move_forward();

protected:
    QList<QPointF> points;
    QPointF dest;
    int point_index;


};

#endif // SENEMY_H
