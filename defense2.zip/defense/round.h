#ifndef ROUND_H
#define ROUND_H

#include <QGraphicsTextItem>

class Round : public QGraphicsTextItem
{
public:
    Round(QGraphicsTextItem* parent = nullptr, int _maxRound = 2);
    void increase();
    int getCurrentRound();
    void gameover();
    int round;
private:

    int  maxRound;
};

#endif // ROUND_H
