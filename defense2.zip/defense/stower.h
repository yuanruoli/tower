#ifndef STOWER_H
#define STOWER_H
#include <QGraphicsPixmapItem>
#include <QGraphicsPolygonItem>
#include <QGraphicsItem>
#include <QPointF>
#include <QObject>

class STower:public QObject,public QGraphicsPixmapItem{
    Q_OBJECT
public:
    STower(QGraphicsItem *parent=0);
    double distanceTo(QGraphicsItem *item);
    virtual void fire();
    QPointF attack_dest;
    QGraphicsPolygonItem *attack_area;
public slots:
        void acquire_target();
private:


    bool has_target;
};

#endif // STOWER_H
