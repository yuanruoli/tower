#include "firsttowericon.h"
#include "game.h"
#include "game2.h"
#include "firsttower.h"

extern Game *game;


BuildFirstTowerIcon::BuildFirstTowerIcon(QGraphicsItem *parent): QGraphicsPixmapItem(parent)
{
    setPixmap(QPixmap(":/resourses/pic/magictower1.png"));

}

void BuildFirstTowerIcon::mousePressEvent(QGraphicsSceneMouseEvent *event){
    count - 0;
    if(!game->build){
        if(game->gold1->getGold()>=200)//new comer
        {
            game->build =  new FirstTower();
            game->setCursor(QString(":/resourses/pic/magictower1.png"));
            for(int i=0;i<200;i++)
                game->gold1->decrease();

        }
    }
    count++;
}
