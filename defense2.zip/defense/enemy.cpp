#include "enemy.h"
#include <QPixmap>
#include <qmath.h>
#include <QTimer>
#include <game.h>
#include <QApplication>
#include <QMessageBox>
#include <QPainter>


extern Game *game;

Enemy::Enemy(QList<QPointF> pointsToFollow,QGraphicsItem *parent)
{
    //set graphics
    setPixmap(QPixmap(":/resourses/pic/dragon1.png"));

    //set points
    points = pointsToFollow;
    point_index = 0;
    dest = points[0];
    rotateToPoint(dest);

    //connect timer to move forward
    QTimer *timer = new QTimer(this);
    connect(timer,SIGNAL(timeout()),this,SLOT(move_forward()));
    timer->start(200);
}

void Enemy::rotateToPoint(QPointF p)
{
    QLineF ln(pos(),p);
    setRotation(-1 * ln.angle());//-1

}

void Enemy::move_forward()
{
    //if close to dest, rotate to dest
    QLineF ln(pos(),dest);
    if(ln.length() < 5){
        point_index++;
        if(point_index>=points.size()){
            return;
        }
        dest=points[point_index];
        rotateToPoint(dest);
    }
    //move froward to current
    int STEP_SIZE = 15;
    double theta = rotation(); //degrees

    double dy = STEP_SIZE * qSin(qDegreesToRadians(theta));
    double dx = STEP_SIZE * qCos(qDegreesToRadians(theta));

    setPos(x()+dx,y()+dy);
    if(pos().x()<=90){//600
        //delete and decrese
        game->health->decrease();
        if(game->health->getHealth() == 0)
        {
            game->close();
            QMessageBox msgBox;
            msgBox.setText("GAME OVER!!");
            msgBox.exec();
            msgBox.setFixedSize(500,500);

        }
        scene()->removeItem(this);
        delete this;
    }

    if(pos().y()<=150){//600
        //delete and decrese
        game->health->decrease();
        if(game->health->getHealth() == 0)
        {
            game->close();
            QMessageBox msgBox;
            msgBox.setText("GAME OVER!!");
            msgBox.exec();
            msgBox.setFixedSize(500,500);

        }
        scene()->removeItem(this);
        delete this;
    }

    //
    if(game->round0->getCurrentRound()==8) {
        game->close();
        QMessageBox msgBox;
        msgBox.setText("WIN");
        msgBox.exec();
        msgBox.setFixedSize(500,500);
        game->round0->increase();
    }
}

