#include "game.h"
#include <QGraphicsScene>
#include "tower.h"
#include "tower2.h"
#include "bullet.h"
#include "enemy.h"
#include "enemy2.h"
#include "firsttowericon.h"
#include "firsttower.h"
#include "secondtower.h"
#include "secondtowericon.h"
#include "QGraphicsLineItem"
#include "round.h"
#include "qdebug.h"
#include <QBrush>
#include <QImage>
#include <QEventLoop>
#include <QGraphicsView>
#include <QMessageBox>
#include <QGraphicsPixmapItem>
#include <QMediaPlayer>

Game::Game(): QGraphicsView()
{
    // create a scene
    scene = new QGraphicsScene();
    scene->setSceneRect(0,0,1500,900);


    //set background
    scene->setBackgroundBrush(QBrush(QImage(":/resourses/pic/map1.png")));

    //set scene
    setScene(scene);
        QMediaPlayer *player = new QMediaPlayer;
        player->setMedia(QUrl("qrc:/resourses/pic/moon.mp3"));//qrc:/pic/hdl.mp3
        player->setVolume(30);
        player->play();

    //set cursor
    cursor = nullptr;
    build = nullptr;
    QGraphicsView::setMouseTracking(true);

    //change window
    setFixedSize(1500,900);
    setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);

    //create a enemy
    spawnTimer = new QTimer(this);
    spawnTimer2 = new QTimer(this);
    spawnTimer21 = new QTimer(this);
    spawnTimer22 = new QTimer(this);
    enemySpawned = 0;
    maxNumberOfEnemies = 15;
    enemySpawned2 = 0;
    maxNumberOfEnemies2 = 50;
    enemySpawned21 = 0;
    maxNumberOfEnemies21 = 15;
    enemySpawned21 = 0;
    maxNumberOfEnemies21 = 50;
    pointsToFollow <<  QPointF(1453,715)<<QPointF(1100,650)<<QPoint(890,720)<<QPointF(800,620)
                    <<QPointF(650,590)<< QPointF(490,740)<<QPointF(90,740);
    pointsToFollow2 <<  QPointF(1453,715)<<QPointF(1100,650)<<QPoint(1080,500)<<QPoint(1100,300)
                        <<QPoint(1100,300)<<QPoint(1115,150)<<QPoint(1115,150);
    createEnemies(5);
    createEnemies(5);
    createEnemies(5);

    createEnemies2(5);
    createEnemies2(5);
    createEnemies2(5);
    createEnemies2(5);
    createEnemies2(5);
    createEnemies2(5);

    createEnemies21(5);
    createEnemies21(5);
    createEnemies21(5);

    createEnemies22(5);
    createEnemies22(5);
    createEnemies22(5);
    createEnemies22(5);
    createEnemies22(5);
    createEnemies22(5);

    //create road
    createRoad();

    //test code
    ft = new BuildFirstTowerIcon();
    ft2 = new BuildSecondTowerIcon();
    ft2->setPos(x(),y()+100);
    scene->addItem(ft);
    scene->addItem(ft2);

    //health
    health = new Health();
    health->setPos(x()+100,y()+40);
    scene->addItem(health);



    //gold
    gold1 = new gold();
    gold1->setPos(x()+100,y()+70);
    scene->addItem(gold1);

    //round
        round0 = new Round();
        round0->setPos(x()+1320,y()+40);
        scene->addItem(round0);

        if(round0->getCurrentRound() == 2/*gameover()*/)
        {
                this->close();
                QMessageBox msgBox;
                msgBox.setText("WIN!!");
                msgBox.exec();
                msgBox.setFixedSize(500,500);

        }


}

void Game::setCursor(QString filename)
{
    if(cursor){
        scene->removeItem(cursor);
        delete cursor;
    }
    cursor = new QGraphicsPixmapItem();
    cursor->setPixmap(QPixmap(filename));
    scene->addItem(cursor);
}

void Game::mouseMoveEvent(QMouseEvent *event)
{
    if(cursor){
        cursor->setPos(event->pos());
    }
}

void Game::mousePressEvent(QMouseEvent *event)
{
    if(build){
        scene->addItem(build);
        build->setPos(event->pos());
        cursor = nullptr;
        build = nullptr;
        //only allow 1 towers
        if(ft->count==2)
        {
            scene->removeItem(ft);
        }
        if(ft2->count==2)
        {
            scene->removeItem(ft2);
        }


    }
    if(build2){
        scene->addItem(build2);
        build2->setPos(event->pos());
        cursor = nullptr;
        build2 = nullptr;
        //only allow 1 towers
        if(ft->count==2)
        {
            scene->removeItem(ft);
        }
        if(ft2->count==2)
        {
            scene->removeItem(ft2);
        }


    }
    else{
        QGraphicsView::mousePressEvent(event);
    }
}

void Game::createEnemies(int numberofEnemies)
{
    enemySpawned = 0;
    maxNumberOfEnemies = numberofEnemies;
    connect(spawnTimer,SIGNAL(timeout()),this,SLOT(spawnEnemy()));
    spawnTimer->start(1500);


}

void Game::createEnemies2(int numberofEnemies)
{
    enemySpawned2 = 0;
    maxNumberOfEnemies2 = numberofEnemies;
    connect(spawnTimer2,SIGNAL(timeout()),this,SLOT(spawnEnemy2()));
    spawnTimer2->start(5000);


}

void Game::createEnemies21(int numberofEnemies)
{
    enemySpawned21 = 0;
    maxNumberOfEnemies21 = numberofEnemies;
    connect(spawnTimer21,SIGNAL(timeout()),this,SLOT(spawnEnemy21()));
    spawnTimer21->start(1500);


}

void Game::createEnemies22(int numberofEnemies)
{
    enemySpawned22 = 0;
    maxNumberOfEnemies22 = numberofEnemies;
    connect(spawnTimer22,SIGNAL(timeout()),this,SLOT(spawnEnemy22()));
    spawnTimer22->start(5000);


}

void Game::createRoad()
{
    for (size_t i = 0, n = pointsToFollow.size()-1; i < n; i++)
    {
        //create line
        QLineF line(pointsToFollow[i],pointsToFollow[i+1]);
        QGraphicsLineItem *lineItem = new QGraphicsLineItem(line);
        //widht and color
        /*QPen pen;
        pen.setWidth(5);
        pen.setColor(Qt::darkCyan);
        //set pend and add to scene
        lineItem->setPen(pen);
        scene->addItem(lineItem);*/

        QLineF line2(pointsToFollow2[i],pointsToFollow2[i+1]);
        QGraphicsLineItem *lineItem2 = new QGraphicsLineItem(line2);
        //widht and color
       /* QPen pen2;
        pen2.setWidth(5);
        pen2.setColor(Qt::blue);
        //set pend and add to scene
        lineItem2->setPen(pen2);
        scene->addItem(lineItem2);*/
    }
}





void Game::spawnEnemy()
{
    //spwan an enemy
    Enemy *enemy = new Enemy(pointsToFollow);
    enemy->setPos(pointsToFollow[0]);
    scene->addItem(enemy);
    enemySpawned+=1;

//maxNumberOfEnemies take charge of the hard level
    if(enemySpawned >= maxNumberOfEnemies)
    {
        spawnTimer->stop();//1500
                round0->increase();
                QEventLoop eventloop;
                QTimer::singleShot(10000, &eventloop, SLOT(quit()));
                eventloop.exec();
                enemySpawned=0;
                spawnTimer->start(1000);
    }
}


void Game::spawnEnemy2()
{
    //spwan an enemy
    Enemy2 *enemy2 = new Enemy2(pointsToFollow);
    enemy2->setPos(pointsToFollow[0]);
    scene->addItem(enemy2);
    //scene->addItem(enemy1);
    enemySpawned2+=1;

}

void Game::spawnEnemy21()
{
    //spwan an enemy
    Enemy *enemy2 = new Enemy(pointsToFollow2);
    enemy2->setPos(pointsToFollow2[0]);
    scene->addItem(enemy2);
    enemySpawned21+=1;

}


void Game::spawnEnemy22()
{
    //spwan an enemy
    Enemy2 *enemy2 = new Enemy2(pointsToFollow2);
    enemy2->setPos(pointsToFollow2[0]);
    scene->addItem(enemy2);
    enemySpawned22+=1;

}

bool Game::gameover()
{
    if(round0->getCurrentRound() == 2) {
        return true;
    }
    else return false;
}

