#include "shealth.h"
#include <QFont>
#include <QDebug>


SHealth::SHealth(QGraphicsItem *parent):QGraphicsTextItem(parent)
{
    //initialize Health to 10
    health = 80;

    //text
    setPlainText(QString("Health: ")+ QString::number(health));
    setDefaultTextColor(Qt::blue);
    setFont(QFont("times",20));//16



}

void SHealth::decrease()
{
    health --;
    setPlainText(QString("Health: ")+ QString::number(health));
    //qDebug()<<health;

}

void SHealth::increase()
{
    health ++;
    setPlainText(QString("Health: ")+ QString::number(health));
    //qDebug()<<health;

}

int SHealth::getHealth()
{
    return health;
}
