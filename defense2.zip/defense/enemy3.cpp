#include "enemy3.h"
#include <QPixmap>
#include <qmath.h>
#include <QTimer>
#include <game2.h>
#include <game.h>
#include <QApplication>
#include <QMessageBox>
#include <QPainter>


extern Game2 *game2;

Enemy3::Enemy3(QList<QPointF> pointsToFollow,QGraphicsItem *parent)
{
    //set graphics
    setPixmap(QPixmap(":/resourses/pic/guard.png"));

    //set points
    points = pointsToFollow;
    point_index = 0;
    dest = points[0];
    rotateToPoint(dest);

    //connect timer to move forward
    QTimer *timer = new QTimer(this);
    connect(timer,SIGNAL(timeout()),this,SLOT(move_forward()));
    timer->start(400);
}

void Enemy3::rotateToPoint(QPointF p)
{
    QLineF ln(pos(),p);
    setRotation(-1 * ln.angle());

}

void Enemy3::move_forward()
{
    //if close to dest, rotate to dest
    QLineF ln(pos(),dest);
    if(ln.length() < 5){
        point_index++;
        if(point_index>=points.size()){
            return;
        }
        dest=points[point_index];
        rotateToPoint(dest);
    }
    //move froward to current
    int STEP_SIZE = 15;
    double theta = rotation(); //degrees

    double dy = STEP_SIZE * qSin(qDegreesToRadians(theta));
    double dx = STEP_SIZE * qCos(qDegreesToRadians(theta));

    setPos(x()+dx,y()+dy);
    if(pos().x()<=90){//600
        //delete and decrese
        game2->health->decrease();
        if(game2->health->getHealth() == 0)
        {
            game2->close();
            QMessageBox msgBox;
            msgBox.setText("GAME OVER!!");
            msgBox.exec();
            msgBox.setFixedSize(500,500);

        }
        scene()->removeItem(this);
        delete this;
    }
}

