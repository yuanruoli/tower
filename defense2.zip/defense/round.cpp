#include "round.h"
#include <QFont>

Round::Round(QGraphicsTextItem* parent, int _maxRound)
{
    maxRound=_maxRound;
    round=0;
    setPlainText(QString("Round: ")+ QString::number(round)+ QString("/")+ QString::number(9));//maxRound
    setDefaultTextColor(Qt::red);
    setFont(QFont("times",20));
}

void Round::increase() {
    round++;
    setPlainText(QString("Round: ")+ QString::number(round)+ QString("/")+ QString::number(9));//maxRound
}

int Round::getCurrentRound() {
    return round;
}
