#ifndef ENEMY2_H
#define ENEMY2_H
#include <QGraphicsPixmapItem>
#include <QObject>
#include <QList>
#include <QPointF>
#include <enemy.h>

class Enemy2: public QObject, public QGraphicsPixmapItem{
    Q_OBJECT
public:
    Enemy2(QList<QPointF> pointsToFollow,QGraphicsItem *parent = 0);
    void rotateToPoint(QPointF p);
    int health=6;
public slots:
    void move_forward();
    //void acquire_target();

private:
    QList<QPointF> points;
    QPointF dest;
    int point_index;


};


#endif // ENEMY2_H
