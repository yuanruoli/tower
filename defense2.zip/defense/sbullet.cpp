#include "sbullet.h"
#include <QPixmap>
#include <QTimer>
#include <qmath.h>
#include <game2.h>
#include <QList>
#include <QTimer>
#include "enemy.h"
#include "enemy3.h"
#include "gold.h"
#include <QPropertyAnimation>
//#include <typeinfo.h>

extern Game2 *game2;

SBullet::SBullet(QGraphicsItem *parent)
{
    //set graphics
    setPixmap(QPixmap(":/resourses/pic/magiclight.png"));


    //timer to move()
    QTimer *move_timer = new QTimer(this);
    connect(move_timer,SIGNAL(timeout()),this,SLOT(move()));
    move_timer->start(10);

    //initialize values
    maxRange = 200;
    distanceTravelled = 0;

}



void SBullet::move()
{
    //if bullets collide, destroy the enemey
        QList<QGraphicsItem *> colliding_items = collidingItems();
        for(int i = 0,n=colliding_items.size();i<n;i++){
            if(typeid(*(colliding_items[i]))==typeid(Enemy)){
                //get gold
                for(int i=0;i<5;i++)
                game2->gold1->increase();
                    scene()->removeItem(colliding_items[i]);
                    delete colliding_items[i];


                scene()->removeItem(this);
                //delete both

                delete this;
                return;
            }
            if(typeid(*(colliding_items[i]))==typeid(Enemy3)){
                //get gold

                for(int i=0;i<100;i++)
                game2->gold1->increase();
                    scene()->removeItem(colliding_items[i]);
                    delete colliding_items[i];


                scene()->removeItem(this);
                //delete both

                delete this;
                return;
            }
            double a=this->scenePos().x();
            double b=this->scenePos().y();
            double c=x();
            double d=y();
            if(sqrt((a-c)*(a-c)+(b-d)*(b-d))>=10)
            {
                scene()->removeItem(this);
                delete this;
            }
        }

        int STEP_SIZE = 3;
        double theta = rotation(); //degrees

        double dy = STEP_SIZE * qSin(qDegreesToRadians(theta));
        double dx = STEP_SIZE * qCos(qDegreesToRadians(theta));

        setPos(x()+dx,y()+dy);
}
