#include "secondtower.h"
#include <QTimer>
#include "bullet2.h"
#include "game.h"
#include <QLineF>
#include <QPen>
#include <QGraphicsPixmapItem>
#include <QGraphicsSceneMouseEvent>

extern Game *game;

SecondTower::SecondTower(QGraphicsItem *parent)
{
    //connect timer to attack
     QTimer *timer = new QTimer();
     connect(timer,SIGNAL(timeout()),this,SLOT(acquire_target()));
     timer->start(100);

     //attack color
     QPen pen;
     pen.setColor(Qt::black);
     attack_area->setPen(pen);
}

void SecondTower::fire()
{
    Bullet2 *bullet = new Bullet2();
    bullet->setPos(x()+50,y()+50);

    QLineF ln(QPoint(x()+50,y()+50),attack_dest);
    int angle = -1*ln.angle();

    bullet->setRotation(angle);
    scene()->addItem(bullet);
}


void SecondTower::acquire_target()
{
    Tower2::acquire_target();
}




