#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "game.h"
#include "game2.h"

class MainWindow : public QMainWindow
{

public:
    MainWindow();
    void start1();
    void start2();
    void gameover();
};

#endif // MAINWINDOW_H
