#include "sfirsttowericon.h"
#include "game.h"
#include "game2.h"
#include "sfirsttower.h"


extern Game2 *game2;

SBuildFirstTowerIcon::SBuildFirstTowerIcon(QGraphicsItem *parent): QGraphicsPixmapItem(parent)
{
    setPixmap(QPixmap(":/resourses/pic/magictower1.png"));

}

void SBuildFirstTowerIcon::mousePressEvent(QGraphicsSceneMouseEvent *event){
    count - 0;
    if(!game2->build2){
        if(game2->gold1->getGold()>=300)//new comer
        {
            game2->build2 =  new SFirstTower();
            game2->setCursor(QString(":/resourses/pic/magictower1.png"));
            for(int i=0;i<300;i++)
                game2->gold1->decrease();

        }
    }
    count++;
}
