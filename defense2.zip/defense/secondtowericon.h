#ifndef BUILDSECONDTOWERICON_H
#define BUILDSECONDTOWERICON_H

#include <QGraphicsPixmapItem>
#include <QGraphicsSceneMouseEvent>

class BuildSecondTowerIcon: public QGraphicsPixmapItem {
public:
    BuildSecondTowerIcon(QGraphicsItem *parent=0);
    void mousePressEvent(QGraphicsSceneMouseEvent *event);
    //propety
    int count;
};

#endif // BUILDSECONDTOWERICON_H
