#include "gold.h"
#include <QFont>
#include <QImage>
#include <QPainter>
#include <QPaintEvent>
#include <QPushButton>
gold::gold(QGraphicsItem *parent):QGraphicsTextItem(parent)
  //initialize Gold to 500
{
    _gold=3000;
    //text out
    setPlainText(QString("Gold: ")+ QString::number(_gold));
    setDefaultTextColor(Qt::darkGreen);
    setFont(QFont("times",20));
}
//painter.drawLine(0,0,100,100);
void gold::decrease()
{
    _gold--;
    setPlainText(QString("Gold ")+ QString::number(_gold));
}
void gold::increase()
{
    _gold++;
    setPlainText(QString("Gold ")+ QString::number(_gold));
}
int gold::getGold()
{
    return _gold;
}

