#include <bullet2.h>
#include <QPixmap>
#include <QTimer>
#include <qmath.h>
#include <game.h>
#include <QList>
#include <QTimer>
#include "enemy.h"
#include "enemy2.h"
#include "gold.h"
#include <QPropertyAnimation>
//#include <typeinfo.h>

extern Game *game;

Bullet2::Bullet2(QGraphicsItem *parent)
{
    //set graphics
    setPixmap(QPixmap(":/resourses/pic/bullet1.png"));


    //timer to move()
    QTimer *move_timer = new QTimer(this);
    connect(move_timer,SIGNAL(timeout()),this,SLOT(move()));
    move_timer->start(50);

    //initialize values
    maxRange = 200;
    distanceTravelled = 0;

}



void Bullet2::move()
{
    //if bullets collide, destroy the enemey
        QList<QGraphicsItem *> colliding_items = collidingItems();
        for(int i = 0,n=colliding_items.size();i<n;i++){
            if(typeid(*(colliding_items[i]))==typeid(Enemy)){
                //get gold
                for(int i=0;i<5;i++)
                game->gold1->increase();
                    scene()->removeItem(colliding_items[i]);
                    delete colliding_items[i];


                scene()->removeItem(this);
                //delete both

                delete this;
                return;
            }
            if(typeid(*(colliding_items[i]))==typeid(Enemy2)){
                //get gold
                for(int i=0;i<5;i++)
                game->gold1->increase();

                    scene()->removeItem(colliding_items[i]);
                    delete colliding_items[i];


                scene()->removeItem(this);
                //delete both

                delete this;
                return;
            }
            double a=this->scenePos().x();
            double b=this->scenePos().y();
            double c=x();
            double d=y();
            if(sqrt((a-c)*(a-c)+(b-d)*(b-d))>=10)
            {
                scene()->removeItem(this);
                delete this;
            }
        }

        int STEP_SIZE = 3;
        double theta = rotation(); //degrees

        double dy = STEP_SIZE * qSin(qDegreesToRadians(theta));
        double dx = STEP_SIZE * qCos(qDegreesToRadians(theta));

        setPos(x()+dx,y()+dy);

}

