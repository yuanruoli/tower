#include "mw1.h"
#include "ui_mw1.h"
#include "icon.h"
#include <QTime>
#include<QTimer>
#include <map>
#include <iostream>

#include "world.h"
#include "rpgobj.h"
#include "mtower.h"
#include <QMediaPlayer>

using namespace std;

MW1::MW1(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MW1)
{
    ui->setupUi(this);

    //init game world
    _game.initWorld("‎⁨‎⁨m⁩/⁨用户⁩/⁨macba⁩/⁨桌面⁩/⁨work/⁩frame.png");//TODO 应该是输入有效的地图文件‎⁨m⁩ ▸ ⁨用户⁩ ▸ ⁨macba⁩ ▸ ⁨桌面⁩ ▸ ⁨work⁩


    timer = new QTimer(this);
    connect(timer,SIGNAL(timeout()),this,SLOT(randomMove()));
        //randomMove()为自定义槽函数
    timer->start(50);
    timer->setInterval(500);

    qsrand(QTime(0,0,0).secsTo(QTime::currentTime()));//设置随机种子
}

MW1::~MW1()
{
    delete ui;
}

void MW1::paintEvent(QPaintEvent *e){
    QPainter *pa;
    pa = new QPainter();
    pa->begin(this);
    this->_game.show(pa);
    //
    QPainter p(this);
        //p.fillRect(288+5 , 224+32+5, 32-10, 32-10, Qt::darkGreen);
        QPolygonF polygon;
        polygon<<QPointF(288+15,256+10)<<QPointF(288+15+32,256+10)<<QPointF(288+5+32,256+32-5)<<QPointF(288+5,256+32-5);
        //p.setBrush(QBrush(Qt::darkGreen,Qt::SolidPattern));
        p.setPen(QPen(Qt::darkRed,3,Qt::SolidLine,Qt::RoundCap));
        //p.setPen(QPen(QColor(0,150,250),1,Qt::SolidLine,Qt::RoundCap));
        p.drawPolygon(polygon);

        QPolygonF polygon2;
        polygon2<<QPointF(288+128+15,256+10)<<QPointF(288+128+15+32,256+10)<<QPointF(288+128+5+32,256+32-5)<<QPointF(288+128+5,256+32-5);
        //p.setBrush(QBrush(Qt::darkGreen,Qt::SolidPattern));
        p.setPen(QPen(Qt::darkRed,3,Qt::SolidLine,Qt::RoundCap));
        //p.setPen(QPen(QColor(0,150,250),1,Qt::SolidLine,Qt::RoundCap));
        p.drawPolygon(polygon2);

        QPolygonF polygon3;
        polygon3<<QPointF(288+32+15,256+10+96)<<QPointF(288+32+15+32,256+10+96)<<QPointF(288+32+5+32,256+32-5+96)<<QPointF(288+32+5,256+32-5+96);
        //p.setBrush(QBrush(Qt::darkGreen,Qt::SolidPattern));
        p.setPen(QPen(Qt::darkRed,3,Qt::SolidLine,Qt::RoundCap));
        //p.setPen(QPen(QColor(0,150,250),1,Qt::SolidLine,Qt::RoundCap));
        p.drawPolygon(polygon3);

        QPolygonF polygon4;
        polygon4<<QPointF(96+15,224+10)<<QPointF(96+15+32,224+10)<<QPointF(96+5+32,224+32-5)<<QPointF(96+5,224+32-5);
        //p.setBrush(QBrush(Qt::darkGreen,Qt::SolidPattern));
        p.setPen(QPen(Qt::darkRed,3,Qt::SolidLine,Qt::RoundCap));
        //p.setPen(QPen(QColor(0,150,250),1,Qt::SolidLine,Qt::RoundCap));
        p.drawPolygon(polygon4);

        QPolygonF polygon5;
        polygon5<<QPointF(96+96+15,224+96+32+10)<<QPointF(96+96+15+32,224+32+96+10)<<QPointF(96+5+96+32,224+32+96+32-5)<<QPointF(96+96+5,224+32+96+32-5);
        //p.setBrush(QBrush(Qt::darkGreen,Qt::SolidPattern));
        p.setPen(QPen(Qt::darkRed,3,Qt::SolidLine,Qt::RoundCap));
        //p.setPen(QPen(QColor(0,150,250),1,Qt::SolidLine,Qt::RoundCap));
        p.drawPolygon(polygon5);

        QPolygonF polygon6;
        polygon6<<QPointF(288+128+15+96,256+10+96)<<QPointF(288+128+15+32+96,256+10+96)<<QPointF(288+128+5+32+96,256+32-5+96)<<QPointF(288+128+5+96,256+32-5+96);
        //p.setBrush(QBrush(Qt::darkGreen,Qt::SolidPattern));
        p.setPen(QPen(Qt::darkRed,3,Qt::SolidLine,Qt::RoundCap));
        //p.setPen(QPen(QColor(0,150,250),1,Qt::SolidLine,Qt::RoundCap));
        p.drawPolygon(polygon6);

    //
    pa->end();

    delete pa;
    //
    //
}

void MW1::keyPressEvent(QKeyEvent *e)
{
    //direction = 1,2,3,4 for 上下左右

    //key 1-marbletower 2-wizardtower 3-scarecrow 4-lighttower
    if(e->key() == Qt::Key_1)
    {
        mtower *t1= new mtower;
        t1->initObj("marbletower");
        t1->setPosX(0);
        t1->setPosY(0);
        this->_objs.push_back(t1);
    }



    if(e->key() == Qt::Key_A)
    {
        this->_game.handlePlayerMove(3,1);
    }
    else if(e->key() == Qt::Key_D)
    {
        this->_game.handlePlayerMove(4,1);
    }
    else if(e->key() == Qt::Key_W)
    {
        this->_game.handlePlayerMove(1,1);
    }
    else if(e->key() == Qt::Key_S)
    {
         this->_game.handlePlayerMove(2,1);
    }
    this->repaint();
}

void MW1::randomMove(){

    int d = 1 + rand()%4;//生成随机运动的方向
    this->_game.handlePlayerMove(d,1);
    this->repaint();
}
