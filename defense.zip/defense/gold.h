#ifndef GOLD_H
#define GOLD_H
#include <QGraphicsTextItem>

class gold:public QGraphicsTextItem
{
public:
    gold(QGraphicsItem *parent = 0);
    void decrease();
    void increase();
    int getGold();
private:
    int _gold;
};

#endif // GOLD_H
