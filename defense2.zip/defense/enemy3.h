#ifndef ENEMY3_H
#define ENEMY3_H
#include <QGraphicsPixmapItem>
#include <QObject>
#include <QList>
#include <QPointF>

class Enemy3: public QObject, public QGraphicsPixmapItem{
    Q_OBJECT
public:
    Enemy3(QList<QPointF> pointsToFollow,QGraphicsItem *parent = 0);
    void rotateToPoint(QPointF p);

    //void fire();
public slots:
    void move_forward();

protected:
    QList<QPointF> points;
    QPointF dest;
    int point_index;
    int health=30;


};

#endif // ENEMY3_H
