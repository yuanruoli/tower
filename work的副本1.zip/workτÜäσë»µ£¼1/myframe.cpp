#include "MyFrame.h"

MyFrame::MyFrame()
{
}

void MyFrame::paintEvent(QPaintEvent *event)
{
    QPainter painter(this);
    painter.drawPixmap(0,0,800,600,QPixmap("m/user/macba/desktop/work/frame.png"));
}
//images/frame.png
