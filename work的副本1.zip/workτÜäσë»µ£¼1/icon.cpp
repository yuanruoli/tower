#include "icon.h"
#include<iostream>
int ICON::GRID_SIZE = 32;


pair<string,ICON> pairArray[] =
{
    make_pair("player",ICON("player",1,13, 1, 2)),
    make_pair("stone",ICON("stone",4,9, 1, 1)),
    make_pair("fruit",ICON("fruit",3,6, 1, 1)),
    make_pair("forests",ICON("forests",6,6,2,2)),
    make_pair("tree",ICON("tree",6,4,2,2)),
    make_pair("treegrass",ICON("treegrass",8,15,3,1)),
    make_pair("road",ICON("road",3,2,3,1)),
    make_pair("sroad",ICON("sroad",6,0,1,3)),
    make_pair("ssroad",ICON("ssroad",5,0,1,1)),
    make_pair("rsign",ICON("rsign",0,5,1,1)),
    make_pair("grass",ICON("grass",0,4,1,1)),
    make_pair("board",ICON("board",7,0,1,3)),
    make_pair("1board",ICON("1board",7,3,1,1)),
    make_pair("roof",ICON("roof",12,4,4,3)),
    make_pair("base",ICON("base",8,4,4,3)),
    make_pair("haystack",ICON("haystack",11,11,2,2)),
    make_pair("fork",ICON("fork",10,11,1,1)),
    make_pair("winebott",ICON("winebott",15,0,1,3)),
    make_pair("enemy1",ICON("enemy1",3,5,1,1)),
    make_pair("enemy2",ICON("enemy2",5,5,1,1)),
    make_pair("enemy3",ICON("enemy3",2,5,1,1)),
    make_pair("enemy4",ICON("enemy4",4,5,1,1)),
    make_pair("wizardtower",ICON("wizardtower",8,12,1,2)),
    make_pair("marbletower",ICON("marbletower",9,12,1,2)),
    make_pair("lighttower",ICON("lighttower",4,5,1,10)),
    make_pair("scarecrow",ICON("scarecrow",1,13,1,2)),
    make_pair("trunk",ICON("trunk",4,8,2,1)),
    make_pair("well",ICON("well",2,10,2,3)),
    make_pair("wines",ICON("wines",12,0,2,2))
};

map<string,ICON> ICON::GAME_ICON_SET(pairArray,pairArray+sizeof(pairArray)/sizeof(pairArray[0]));


ICON::ICON(string name, int x, int y, int w, int h){
    this->typeName = name;
    this->srcX = x;
    this->srcY = y;
    this->width = w;
    this->height = h;
}

ICON ICON::findICON(string type){
    map<string,ICON>::iterator kv;
    kv = ICON::GAME_ICON_SET.find(type);
    if (kv==ICON::GAME_ICON_SET.end()){

       cout<<"Error: cannot find ICON"<<endl;
       return ICON();
    }
    else{
        return kv->second;
    }
}
