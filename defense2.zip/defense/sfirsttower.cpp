#include "sfirsttower.h"
#include <QTimer>
#include "sbullet.h"
#include "game.h"
#include "game2.h"
#include <QLineF>
#include <QPen>

#include "game.h"
#include "game2.h"

extern Game2 *game2;

SFirstTower::SFirstTower(QGraphicsItem *parent)
{


   //connect timer to attack
    QTimer *timer = new QTimer();
    connect(timer,SIGNAL(timeout()),this,SLOT(acquire_target()));
    timer->start(1000);

    //attack color
    QPen pen;
    pen.setColor(Qt::darkGray);
    attack_area->setPen(pen);

}

void SFirstTower::fire()
{
    SBullet *bullet = new SBullet();
    bullet->setPos(x()+25,y()+25);

    QLineF ln(QPoint(x()+50,y()+50),attack_dest);
    int angle = -1*ln.angle();

    bullet->setRotation(angle);
    scene()->addItem(bullet);
}

void SFirstTower::acquire_target()
{
    STower::acquire_target();
}





