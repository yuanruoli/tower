#ifndef SBULLET_H
#define SBULLET_H
#include <QGraphicsPixmapItem>
#include <QObject>
#include <QGraphicsItem>

class SBullet:public QObject,public QGraphicsPixmapItem{
    Q_OBJECT
public:
    SBullet(QGraphicsItem *parent=0);
public slots:
    void move();
private:
    double maxRange;
    double distanceTravelled;
    int timerId;
};
#endif // SBULLET_H
